# 5 Minuten Spielprojekt

Regelstudienzeit: 5 Minuten<br>
Projekt für den Kurs "Computerspiele"

